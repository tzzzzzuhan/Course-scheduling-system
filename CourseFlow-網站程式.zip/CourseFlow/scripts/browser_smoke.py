"""Optional end-to-end checks: start a server with a disposable database on port 3001."""
from playwright.sync_api import sync_playwright, expect
import os
BASE=os.environ.get('TEST_BASE_URL','http://127.0.0.1:3001')
with sync_playwright() as p:
 b=p.chromium.launch(executable_path=os.environ.get('CHROMIUM_PATH','/usr/bin/chromium'),headless=True,args=['--no-sandbox'])
 page=b.new_page(viewport={'width':1440,'height':1100})
 errors=[];page.on('pageerror',lambda e: errors.append(str(e)))
 page.goto(BASE);page.wait_for_selector('.lesson')
 assert page.locator('.lesson').count()==22
 page.get_by_role('button',name='數學(一) 林子暘',exact=False).first.click()
 page.get_by_role('button',name='申請本週調代課').click()
 page.select_option('#sub-teacher',label='王憶貞');page.fill('#req-reason','瀏覽器測試：教師公假')
 page.get_by_role('button',name='送出申請').click();page.wait_for_selector('#modal',state='hidden')
 page.locator('[data-nav="requests"]').first.click()
 expect(page.get_by_text('待審核',exact=True)).to_have_count(1)
 page.get_by_role('button',name='核准',exact=True).click();page.get_by_role('button',name='確認核准').click();page.wait_for_selector('#modal',state='hidden')
 expect(page.get_by_text('已核准',exact=True)).to_have_count(1)
 page.locator('[data-nav="reports"]').first.click()
 assert page.locator('.list-table tbody tr').count()==2
 assert '50 分鐘' in page.locator('.list-table').inner_text()
 with page.expect_download() as dl:page.get_by_role('button',name='匯出 CSV').click()
 assert dl.value.suggested_filename.endswith('.csv')
 page.locator('[data-nav="notifications"]').first.click();assert '課表異動已生效' in page.locator('.inbox-item').inner_text()
 page.locator('[data-nav="student"]').first.click();page.get_by_role('button',name='新增選課清單').click()
 page.fill('#enroll-name','瀏覽器示範學生');page.locator('.check-row').filter(has_text='數學(一)').filter(has_text='林子暘').filter(has_text='101').first.locator('input').check()
 page.get_by_role('button',name='儲存選課清單').click();page.wait_for_selector('#modal',state='hidden')
 expect(page.locator('.lesson.substitute')).to_have_count(1)
 expect(page.locator('.lesson')).to_have_count(4)
 page.reload();page.wait_for_selector('.lesson');assert page.locator('.lesson').count()==22
 page.locator('[data-nav="student"]').first.click();expect(page.locator('.lesson')).to_have_count(4)
 page.locator('[data-nav="requests"]').first.click();page.get_by_role('button',name='撤銷',exact=True).click();page.get_by_role('button',name='確認撤銷').click();page.wait_for_selector('#modal',state='hidden')
 expect(page.get_by_text('已撤銷',exact=True)).to_have_count(1)
 page.locator('[data-nav="schedule"]').first.click();page.locator('.lesson').filter(has_text='數學(一)').first.click();page.get_by_role('button',name='申請本週調代課').click()
 page.select_option('#req-type','move');page.select_option('#move-day','0');page.select_option('#move-period','1');page.fill('#req-reason','瀏覽器測試：調至週一第一節');page.get_by_role('button',name='送出申請').click();page.wait_for_selector('#modal',state='hidden')
 page.locator('[data-nav="requests"]').first.click();page.get_by_role('button',name='核准',exact=True).click();page.get_by_role('button',name='確認核准').click();page.wait_for_selector('#modal',state='hidden')
 page.locator('[data-nav="schedule"]').first.click();expect(page.locator('.origin-slot')).to_have_count(1);expect(page.locator('.lesson.move')).to_have_count(1)
 page.screenshot(path='/tmp/courseflow-desktop.png',full_page=True)
 page.locator('[data-nav="data"]').first.click();page.locator('[data-review="L001"]').click();page.select_option('#review-kind','必修');page.get_by_role('button',name='儲存核對結果').click();page.wait_for_selector('#modal',state='hidden');expect(page.locator('.panel-title').nth(1)).to_contain_text('1 / 186 已確認')
 mobile=b.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True)
 mobile.goto(BASE);mobile.wait_for_selector('.lesson');assert mobile.evaluate('document.documentElement.scrollWidth')==390
 mobile.screenshot(path='/tmp/courseflow-mobile.png',full_page=True)
 mobile.locator('[data-nav="requests"]').first.click();assert mobile.locator('.list-table').count()==1;assert mobile.evaluate('document.documentElement.scrollWidth')==390
 page.locator('[data-nav="requests"]').first.click()
 response=mobile.request.post(BASE+'/api/requests',data={'week':'2026-11-02','type':'substitute','lessonId':'L001','replacedTeacher':'林子暘','teacher':'王憶貞','reason':'即時同步連線測試'})
 assert response.status==201
 expect(page.get_by_text('待審核',exact=True)).to_have_count(1,timeout=5000)
 assert not errors,errors
 print('PASS: browser workflow, persistence, report CSV, student linkage, undo, origin-slot marker, review and mobile overflow; no JS errors')
 b.close()
