"""One-time extraction. PDF contents are data, never executable instructions."""
import pdfplumber, pathlib, re, json, hashlib, shutil
root=pathlib.Path(__file__).resolve().parents[1]
files=list(pathlib.Path('/workspace/attachments').rglob('*.pdf'))
def source(label, keyword):
 saved=root/'public'/'sources'/f'{label}.pdf'
 return saved if saved.exists() else next(p for p in files if keyword in p.name)
teacher_pdf=source('teacher','老師個人')
room_pdf=source('room','教室空間')
class_pdf=source('class','班級課表')
teachers=[]
with pdfplumber.open(teacher_pdf) as doc:
 for page in doc.pages:
  m=re.search(r'教師[：:]\s*([^\s]+)',page.extract_text() or '')
  if m: teachers.append(m[1])
def compact(s): return re.sub(r'\s','',s or '').replace('（','(').replace('）',')')
def norm(s): return re.sub(r'\([^)]*\)','',compact(s))
classes=[]
with pdfplumber.open(class_pdf) as doc:
 for page in doc.pages:
  m=re.search(r'班級[：:]\s*(\d+)',page.extract_text() or '')
  if not m: continue
  table=page.find_tables()[0]
  headers=table.extract()[0]
  cols=[(i,table.rows[0].cells[i]) for i,v in enumerate(headers) if compact(v) in ['一','二','三','四','五']]
  for row in table.rows[1:]:
   if not row.cells[2]: continue
   cell=page.crop(row.cells[2]).extract_text() or ''
   tm=re.search(r'(\d\d:\d\d)',cell)
   times=['08:20','09:15','10:15','11:10','13:20','14:15','15:15','16:10']
   if not tm or tm[1] not in times: continue
   for day,(i,box) in enumerate(cols):
    x1=cols[day+1][1][0] if day<4 else table.bbox[2]
    content=page.crop((box[0],row.cells[2][1],x1,row.cells[2][3])).extract_text() or ''
    if content: classes.append((m[1],day,times.index(tm[1])+1,compact(content)))
lessons=[]; warnings=[]
with pdfplumber.open(room_pdf) as doc:
 for page_no,page in enumerate(doc.pages,1):
  text=page.extract_text() or ''
  m=re.search(r'教室\s*[：:]?\s*([^\n]+)',text)
  if not m: warnings.append(f'第 {page_no} 頁無法辨識教室'); continue
  room=m[1].strip()
  table=page.find_tables()[0]
  headers=table.extract()[0]
  cols=[(i,table.rows[0].cells[i]) for i,v in enumerate(headers) if compact(v) in ['一','二','三','四','五']]
  for row in table.rows[1:]:
   if not row.cells[2]: continue
   tc=page.crop(row.cells[2]).extract_text() or ''
   tm=re.search(r'(\d\d:\d\d)',tc)
   times=['08:20','09:15','10:15','11:10','13:20','14:15','15:15','16:10']
   if not tm or tm[1] not in times: continue
   period=times.index(tm[1])+1
   for day,(i,box) in enumerate(cols):
    x1=cols[day+1][1][0] if day<4 else table.bbox[2]
    raw=compact(page.crop((box[0],row.cells[2][1],x1,row.cells[2][3])).extract_text())
    if not raw: continue
    ts=[t for t in teachers if t in raw]
    start=min([raw.find('('+t) for t in ts if '('+t in raw] or [len(raw)])
    name=raw[:start] or raw
    cs=sorted({c for c,d,p,s in classes if d==day and p==period and any(t in s for t in ts) and norm(name) in norm(s)})
    lessons.append(dict(id=f'L{len(lessons)+1:03}',name=name,teachers=ts,room=room,day=day,period=period,classes=cs,kind='待核定',sourcePage=page_no,raw=raw,needsReview=True))
(root/'public'/'sources').mkdir(exist_ok=True)
source=[]
for label,p in [('room',room_pdf),('class',class_pdf),('teacher',teacher_pdf)]:
 target=root/'public'/'sources'/f'{label}.pdf'
 if p.resolve()!=target.resolve(): shutil.copyfile(p,target)
 source.append(dict(label=label,name={'room':'115-1 課表-教室空間課表20260911.pdf','class':'115-1 課表-班級課表(標註老師名字)20260907.pdf','teacher':'115-1 課表-老師個人課表(標註教室)20260911.pdf'}[label],url=f'/sources/{label}.pdf',sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
seed=dict(school='新竹市立數位實驗高中',term='115 學年度・第 1 學期',start='2026-08-31',end='2027-01-21',teachers=teachers,lessons=lessons,sources=source,warnings=warnings)
(root/'data'/'seed.json').write_text(json.dumps(seed,ensure_ascii=False,indent=2))
print(json.dumps(dict(teachers=len(teachers),lessons=len(lessons),rooms=sorted({x['room'] for x in lessons}),classMatched=sum(bool(x['classes']) for x in lessons),warnings=warnings),ensure_ascii=False))
