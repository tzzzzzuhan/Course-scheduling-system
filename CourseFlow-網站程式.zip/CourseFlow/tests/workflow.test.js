import { test } from "node:test";
import assert from "node:assert/strict";
import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import {
  seed,
  createStore,
  createApp,
  makeRequest,
  schedule,
  conflicts,
  validWeek,
} from "../server.js";
const week = "2026-10-19",
  l = seed.lessons[0];
const sub = (extra = {}) => ({
  week,
  type: "substitute",
  lessonId: l.id,
  replacedTeacher: l.teachers[0],
  teacher: "王憶貞",
  reason: "教師公假，安排代課",
  ...extra,
});
const move = (extra = {}) => ({
  week,
  type: "move",
  lessonId: l.id,
  day: 0,
  period: 1,
  room: "101",
  reason: "校務活動調整課程",
  ...extra,
});
async function fixture(fn) {
  const store = createStore();
  const app = createApp(store);
  await new Promise((r) => app.listen(0, "127.0.0.1", r));
  const base = `http://127.0.0.1:${app.address().port}/api/`;
  const call = async (p, data) => {
    const r = await fetch(base + p, {
      method: data ? "POST" : "GET",
      headers: data ? { "content-type": "application/json" } : {},
      body: data ? JSON.stringify(data) : undefined,
    });
    return { status: r.status, body: await r.json() };
  };
  try {
    await fn(call, store, base);
  } finally {
    await new Promise((r) => app.close(r));
    store.close();
  }
}
test("PDF extraction retains 186 periods, 26 teachers and source provenance", () => {
  assert.equal(seed.lessons.length, 186);
  assert.equal(seed.teachers.length, 26);
  assert(
    seed.lessons.every(
      (l) => l.sourcePage && l.needsReview && l.teachers.length,
    ),
  );
  assert.equal(l.name, "數學(一)");
  assert.deepEqual(l.classes, ["101"]);
  assert.equal(new Set(seed.lessons.map((l) => l.room)).size, 11);
});
test("date input rejects invalid, non-Monday and out-of-semester values", () => {
  for (const d of ["2026-10-20", "2026-02-30", "2026-02-23", "not a date"])
    assert.throws(() => validWeek(d));
  assert.doesNotThrow(() => validWeek(week));
});
test("pending approval, week isolation, notification and cancellation lifecycle", async () =>
  fixture(async (call) => {
    const created = await call("requests", sub());
    assert.equal(created.status, 201);
    const id = created.body.id;
    let current = await call("state?week=" + week);
    assert.deepEqual(current.body.lessons[0].teachers, l.teachers);
    let approved = await call("decision", { id, action: "approve" });
    assert.equal(approved.status, 200);
    current = await call("state?week=" + week);
    assert.deepEqual(current.body.lessons[0].teachers, ["王憶貞"]);
    assert.equal(current.body.notifications.length, 1);
    const other = await call("state?week=2026-10-26");
    assert.deepEqual(other.body.lessons[0].teachers, l.teachers);
    assert.equal(
      (await call("decision", { id, action: "approve" })).status,
      400,
    );
    assert.equal(
      (await call("decision", { id, action: "cancel" })).status,
      200,
    );
    current = await call("state?week=" + week);
    assert.deepEqual(current.body.lessons[0].teachers, l.teachers);
    assert.equal(current.body.notifications.length, 2);
    assert.equal(current.body.audit.length, 3);
  }));
test("move changes only selected occurrence, preserves original, restores on cancellation", async () =>
  fixture(async (call) => {
    const r = await call("requests", move());
    assert.equal(r.status, 201);
    await call("decision", { id: r.body.id, action: "approve" });
    let s = (await call("state?week=" + week)).body;
    assert.equal(s.lessons[0].day, 0);
    assert.equal(s.lessons[0].period, 1);
    assert.equal(s.lessons[0].original.day, 1);
    await call("decision", { id: r.body.id, action: "cancel" });
    s = (await call("state?week=" + week)).body;
    assert.equal(s.lessons[0].day, 1);
  }));
test("reject teacher and room collisions", () => {
  const store = createStore(),
    s = store.read();
  const occupied = seed.lessons.find(
    (x) =>
      x.day === l.day &&
      x.period === l.period &&
      x.id !== l.id &&
      !x.teachers.includes(l.teachers[0]),
  );
  assert(occupied);
  assert.throws(
    () => makeRequest(s, sub({ teacher: occupied.teachers[0] })),
    /衝堂/,
  );
  assert.throws(
    () =>
      makeRequest(
        s,
        move({
          day: occupied.day,
          period: occupied.period,
          room: occupied.room,
        }),
      ),
    /已有/,
  );
  store.close();
});
test("individual enrolled students participate in conflict detection", () => {
  const store = createStore(),
    s = store.read();
  const other = seed.lessons.find(
    (x) => x.id !== l.id && (x.day !== l.day || x.period !== l.period),
  );
  s.enrollments.push({
    id: "E1",
    name: "測試同學",
    lessonIds: [l.id, other.id],
  });
  const issues = conflicts(s, week, [
    { id: l.id, day: other.day, period: other.period },
  ]);
  assert(issues.some((x) => x.includes("測試同學")));
  store.close();
});
test("co-teaching substitute replaces only chosen teacher", () => {
  const store = createStore(),
    s = store.read();
  let found;
  for (const lesson of seed.lessons.filter((x) => x.teachers.length > 1)) {
    for (const t of seed.teachers.filter((t) => !lesson.teachers.includes(t))) {
      try {
        found = {
          lesson,
          r: makeRequest(
            s,
            sub({
              lessonId: lesson.id,
              replacedTeacher: lesson.teachers[0],
              teacher: t,
            }),
          ),
        };
        break;
      } catch {}
    }
    if (found) break;
  }
  assert(found);
  assert.equal(
    found.r.changes[0].teachers.length,
    found.lesson.teachers.length,
  );
  assert.deepEqual(
    found.r.changes[0].teachers.slice(1),
    found.lesson.teachers.slice(1),
  );
  store.close();
});
test("two-course swap is atomic and retains original rooms", () => {
  const store = createStore(),
    s = store.read();
  const other = seed.lessons.find(
    (x) =>
      x.id !== l.id &&
      x.room === l.room &&
      JSON.stringify(x.teachers) === JSON.stringify(l.teachers),
  );
  const r = makeRequest(s, {
    week,
    type: "swap",
    lessonId: l.id,
    otherId: other.id,
    reason: "雙方同意互換課程",
  });
  r.status = "approved";
  s.requests.push(r);
  const ls = schedule(s, week);
  assert.equal(ls.find((x) => x.id === l.id).day, other.day);
  assert.equal(ls.find((x) => x.id === other.id).period, l.period);
  assert.equal(ls.find((x) => x.id === other.id).room, other.room);
  store.close();
});
test("approval rechecks newly occupied substitute teacher", async () =>
  fixture(async (call, store) => {
    const r = await call("requests", sub());
    const s = store.read();
    const other = seed.lessons.find(
      (x) => x.id !== l.id && x.teachers.includes("王憶貞"),
    );
    s.requests.push({
      id: "concurrent",
      status: "approved",
      week,
      type: "move",
      changes: [
        { id: other.id, day: l.day, period: l.period, room: other.room },
      ],
    });
    store.write(s);
    const decision = await call("decision", {
      id: r.body.id,
      action: "approve",
    });
    assert.equal(decision.status, 400);
    assert.match(decision.body.error, /衝堂/);
    assert.equal(store.read().requests[0].status, "pending");
  }));
test("student enrollment saves, rejects overlapping selections and syncs changes", async () =>
  fixture(async (call) => {
    const r = await call("enrollments", {
      name: "示範同學",
      lessonIds: [l.id],
    });
    assert.equal(r.status, 200);
    const sameSlot = seed.lessons.find(
      (x) => x.day === l.day && x.period === l.period && x.id !== l.id,
    );
    assert.equal(
      (
        await call("enrollments", {
          name: "衝堂測試",
          lessonIds: [l.id, sameSlot.id],
        })
      ).status,
      400,
    );
    const req = await call("requests", move());
    await call("decision", { id: req.body.id, action: "approve" });
    const current = (await call("state?week=" + week)).body;
    const enrolled = current.enrollments[0];
    assert.equal(
      current.lessons.find((l) => enrolled.lessonIds.includes(l.id)).day,
      0,
    );
  }));
test("review classifications and data survive database reopening", () => {
  const dir = mkdtempSync(path.join(tmpdir(), "courseflow-"));
  const file = path.join(dir, "test.sqlite");
  let store = createStore(file);
  const s = store.read();
  s.review[l.id] = { kind: "必修", classes: ["101"], needsReview: false };
  store.write(s);
  store.close();
  store = createStore(file);
  assert.equal(schedule(store.read(), week)[0].kind, "必修");
  assert.equal(schedule(store.read(), week)[0].needsReview, false);
  store.close();
  rmSync(dir, { recursive: true });
});
test("duplicate changes, invalid replacement and end-of-term move are rejected", () => {
  const store = createStore(),
    s = store.read();
  const r = makeRequest(s, sub());
  s.requests.push(r);
  assert.throws(() => makeRequest(s, sub()), /已有/);
  s.requests = [];
  assert.throws(
    () => makeRequest(s, sub({ replacedTeacher: "不存在" })),
    /被代課/,
  );
  assert.throws(
    () => makeRequest(s, move({ week: "2027-01-18", day: 4 })),
    /超出/,
  );
  store.close();
});
test("API rejects cross-origin writes and malformed payloads", async () =>
  fixture(async (call, store, base) => {
    const response = await fetch(base + "requests", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Origin: "https://untrusted.example",
      },
      body: JSON.stringify(sub()),
    });
    assert.equal(response.status, 400);
    assert.match((await response.json()).error, /來源不允許/);
    assert.equal(
      (await call("requests", { week, type: "unknown" })).status,
      400,
    );
    assert.equal(
      (
        await call("review", {
          id: l.id,
          kind: "必修",
          classes: ["101<script>"],
        })
      ).status,
      400,
    );
  }));

test("live update stream publishes persisted changes", async () =>
  fixture(async (call, store, base) => {
    const abort = new AbortController();
    const response = await fetch(base + "events", { signal: abort.signal });
    assert.equal(response.headers.get("content-type"), "text/event-stream");
    const reader = response.body.getReader();
    await reader.read();
    const r = await call("requests", sub());
    assert.equal(r.status, 201);
    const event = await reader.read();
    assert.match(new TextDecoder().decode(event.value), /data: updated/);
    abort.abort();
    await reader.cancel().catch(() => {});
  }));
