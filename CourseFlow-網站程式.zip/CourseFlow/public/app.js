const paths = {
  grid: "M3 3h7v7H3z M14 3h7v7h-7z M3 14h7v7H3z M14 14h7v7h-7z",
  calendar: "M4 5h16v16H4z M16 3v4 M8 3v4 M4 10h16 M8 14h2 M14 14h2 M8 18h2",
  swap: "M4 7h15l-4-4 M20 17H5l4 4 M19 7l-4 4 M5 17l4-4",
  users:
    "M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2 M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8 M22 21v-2a4 4 0 0 0-3-3.87 M16 3.13a4 4 0 0 1 0 7.75",
  check: "M9 11l3 3 8-9 M20 12v8H4V4h10",
  chart: "M4 3v18h17 M9 17v-5 M14 17V7 M19 17V4",
  bell: "M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9 M10 21h4",
  book: "M3 4h7l2 2 2-2h7v15h-7l-2 2-2-2H3z M12 6v15",
  plus: "M12 5v14 M5 12h14",
  download: "M12 3v12 M7 10l5 5 5-5 M4 16v5h16v-5",
  search: "M21 21l-5-5 M10 17a7 7 0 1 0 0-14 7 7 0 0 0 0 14",
  pin: "M20 10c0 6-8 12-8 12S4 16 4 10a8 8 0 1 1 16 0z M12 13a3 3 0 1 0 0-6 3 3 0 0 0 0 6",
  left: "M15 5l-7 7 7 7",
  right: "M9 5l7 7-7 7",
  info: "M12 8h.01 M12 11v6 M22 12a10 10 0 1 0-20 0 10 10 0 0 0 20 0",
  shield: "M12 3l8 4v5c0 6-8 10-8 10S4 18 4 12V7z M8 12l3 3 5-6",
  clock: "M12 7v5l3 2 M22 12a10 10 0 1 0-20 0 10 10 0 0 0 20 0",
  file: "M14 2H4v20h16V8z M14 2v6h6 M8 13h8 M8 17h5",
  close: "M6 6l12 12 M18 6L6 18",
  spark: "M12 3l2.5 6.5L21 12l-6.5 2.5L12 21l-2.5-6.5L3 12l6.5-2.5z",
  arrow: "M5 12h14 M14 7l5 5-5 5",
};
const icon = (n) =>
  `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="${paths[n] || paths.calendar}"/></svg>`;
const $ = (s) => document.querySelector(s),
  esc = (s) =>
    String(s ?? "").replace(
      /[&<>"']/g,
      (c) =>
        ({
          "&": "&amp;",
          "<": "&lt;",
          ">": "&gt;",
          '"': "&quot;",
          "'": "&#39;",
        })[c],
    );
const dayNames = ["一", "二", "三", "四", "五"],
  times = [
    "08:20",
    "09:15",
    "10:15",
    "11:10",
    "13:20",
    "14:15",
    "15:15",
    "16:10",
  ],
  ends = [
    "09:10",
    "10:05",
    "11:05",
    "12:00",
    "14:10",
    "15:05",
    "16:05",
    "17:00",
  ];
const typeNames = { substitute: "代課", move: "調課", swap: "互換調課" },
  statusNames = {
    pending: "待審核",
    approved: "已核准",
    rejected: "已退回",
    cancelled: "已撤銷",
  };
let S,
  page = "schedule",
  view = "room",
  selection = "101",
  query = "",
  week = initialWeek(),
  studentId = localStorage.getItem("courseflow-student") || "",
  reportMonth = "2026-10",
  reviewPage = 0;
let lastFocus = null;
function initialWeek() {
  const d = new Date();
  const taipei = new Date(
    d.toLocaleString("en-US", { timeZone: "Asia/Taipei" }),
  );
  const day = taipei.getDay();
  taipei.setDate(taipei.getDate() - (day === 0 ? 6 : day - 1));
  const v = `${taipei.getFullYear()}-${String(taipei.getMonth() + 1).padStart(2, "0")}-${String(taipei.getDate()).padStart(2, "0")}`;
  return v < "2026-08-31" || v > "2027-01-21" ? "2026-10-19" : v;
}
const dateAt = (w, d) => {
  const date = new Date(w + "T00:00:00Z");
  date.setUTCDate(date.getUTCDate() + d);
  return date.toISOString().slice(0, 10);
};
const fmtDate = (s) => {
  const d = new Date(s + "T00:00:00Z");
  return `${String(d.getUTCMonth() + 1).padStart(2, "0")}.${String(d.getUTCDate()).padStart(2, "0")}`;
};
const stamp = (s) =>
  new Date(s).toLocaleString("zh-TW", {
    timeZone: "Asia/Taipei",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  });
async function api(url, data) {
  const r = await fetch("/api/" + url, {
    method: data ? "POST" : "GET",
    headers: data ? { "Content-Type": "application/json" } : {},
    body: data ? JSON.stringify(data) : undefined,
  });
  const b = await r.json();
  if (!r.ok) throw Error(b.error || "請求失敗");
  return b;
}
async function refresh() {
  S = await api("state?week=" + week);
  render();
}
function toast(s) {
  $("#toast").textContent = s;
  $("#toast").style.display = "block";
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => ($("#toast").style.display = "none"), 4500);
}
const original = (l) => S.lessons.find((x) => x.id === l);
const student = () => S.enrollments.find((e) => e.id === studentId);
function navButton(id, label, ic, count = "") {
  return `<button class="nav ${page === id ? "active" : ""}" data-nav="${id}">${icon(ic)}<span>${label}</span>${count ? `<span class="count">${count}</span>` : ""}</button>`;
}
function render() {
  const pending = S.requests.filter((r) => r.status === "pending").length,
    unread = S.notifications.filter((n) => !n.read).length;
  const titles = {
    schedule: ["週課表總覽", "每一堂課的安排，都在這裡。"],
    requests: ["調代課管理", "從申請到公告，讓每一次異動都有跡可循。"],
    student: ["我的課表", "依照你的選課清單，找到屬於自己的學習節奏。"],
    reports: ["代課時數報表", "清楚掌握每月代課與被代課節數。"],
    notifications: ["通知中心", "所有課程異動，集中在這裡。"],
    data: ["課表資料管理", "保留原始來源，逐堂核對，建立可靠的學期課表。"],
  };
  const t = titles[page];
  $("#app").innerHTML =
    `<aside class="sidebar"><div class="brand"><div class="brand-icon">${icon("book")}</div><div class="brand-text">課序<small>COURSEFLOW</small></div></div><div class="school">新竹市立數位實驗高中<br><b>教務管理工作台</b></div><div class="nav-label">工作空間 WORKSPACE</div>${navButton("schedule", "週課表總覽", "calendar")}${navButton("requests", "調代課管理", "swap", pending || "")}${navButton("student", "我的課表", "users")}<div class="nav-label">管理與紀錄</div>${navButton("reports", "時數統計報表", "chart")}${navButton("notifications", "通知中心", "bell", unread || "")}${navButton("data", "課表資料管理", "file")}<div class="side-bottom"><div class="side-note"><b>${icon("shield")} 校務示範工作區</b>使用實際 PDF 課表資料<br>異動與選課儲存於本機資料庫<br>尚未連接學校帳號及外部通知</div><div class="side-foot">115 學年度　第 1 學期<br>COURSEFLOW © 2026</div></div></aside><main class="main"><header class="topbar"><div class="breadcrumb">教務工作台 ${icon("right")} <strong>${t[0]}</strong></div><div class="top-actions"><span class="term">115－1 學期</span><button class="ghost bell" data-nav="notifications" aria-label="通知中心">${icon("bell")}${unread ? '<i class="dot"></i>' : ""}</button><div class="user"><div class="avatar">教</div><div><strong>教務工作區</strong><small>示範管理員</small></div></div></div></header><div class="content"><div class="page-head"><div><div class="eyebrow">ACADEMIC AFFAIRS / ${page.toUpperCase()}</div><h1>${t[0]}<span style="color:#aab5a0;font-size:19px;font-weight:400;margin-left:10px">${page === "schedule" ? "Weekly schedule" : ""}</span></h1><p>${t[1]}</p></div><div class="head-actions">${page === "schedule" ? `<button class="export" data-action="export">${icon("download")} 匯出課表</button>` : ""}${["schedule", "requests"].includes(page) ? `<button class="primary" data-action="new">${icon("plus")} 新增調代課</button>` : ""}</div></div>${stats()}${page === "schedule" ? schedulePage() : page === "student" ? studentPage() : page === "requests" ? requestsPage() : page === "reports" ? reportsPage() : page === "notifications" ? notificationsPage() : dataPage()}<div class="footer"><span>課序 CourseFlow · 讓教學有序，讓學習自由。</span><span>資料保留原始 PDF 來源　／　${S.lessons.filter((l) => l.needsReview).length} 堂待人工核對</span></div></div></main>`;
  bind();
}
function stats() {
  const approved = S.requests.filter(
    (r) => r.week === week && r.status === "approved",
  );
  const sub = approved.filter((r) => r.type === "substitute");
  const labels = [
    [
      "本學期課程時段",
      S.lessons.length,
      "堂",
      "來自 11 間教室的原始課表",
      "calendar",
    ],
    [
      "本週調課",
      approved.filter((r) => r.type !== "substitute").length,
      "筆",
      "僅計算已核准異動",
      "swap",
    ],
    ["本週代課", sub.length, "堂", "原授課與代課老師同步顯示", "users"],
    [
      "待審核申請",
      S.requests.filter((r) => r.status === "pending").length,
      "筆",
      "核准後才會更新週課表",
      "check",
    ],
  ];
  return `<section class="stats" aria-label="課務統計">${labels.map(([l, n, u, f, ic]) => `<div class="stat"><div class="stat-label">${l}</div><div class="stat-icon">${icon(ic)}</div><div class="stat-number">${n}<small>${u}</small></div><div class="stat-foot">${f}</div></div>`).join("")}</section>`;
}
function filteredLessons(personal = false) {
  let ls = S.lessons.filter((l) => dateAt(week, l.day) <= S.end);
  if (personal)
    ls = student() ? ls.filter((l) => student().lessonIds.includes(l.id)) : [];
  else if (view === "room") ls = ls.filter((l) => l.room === selection);
  else if (view === "teacher")
    ls = ls.filter((l) => l.teachers.includes(selection));
  else if (view === "class")
    ls = ls.filter((l) => l.classes.includes(selection));
  return ls.filter((l) =>
    `${l.name}${l.teachers.join("")}${l.room}`.includes(query),
  );
}
function schedulePage() {
  return `<div class="workspace"><section class="panel">${scheduleTop(false)}${timetable(false)}</section><aside class="aside-stack">${weeklyAside()}<section class="panel"><div class="aside-title">課表小提醒 ${icon("book")}</div><div class="aside-body aside-info">所有異動只套用至指定週次，原始學期課表不會被覆蓋。<br><br><span style="color:#597748">●</span>　共同授課保留多位授課老師<br><span style="color:#bb9857">●</span>　必選修分類待學校核定</div></section><section class="tip-panel"><h3>${icon("spark")} 一人一張，專屬課表</h3><p>跨班選修不用再對照多份課表。建立個人選課清單，課程異動也會自動同步。</p><button class="text-action" data-nav="student">前往我的課表　→</button></section></aside></div>${sourceBanner()}`;
}
function scheduleTop(personal) {
  let options = [];
  if (!personal) {
    options =
      view === "room"
        ? [...new Set(S.lessons.map((l) => l.room))]
        : view === "teacher"
          ? S.teachers
          : [...new Set(S.lessons.flatMap((l) => l.classes))].sort();
    if (!options.includes(selection)) selection = options[0] || "";
  }
  return `<div class="panel-top"><div class="panel-title">${icon("calendar")} ${personal ? "個人週課表" : "課表總覽"} <span class="subtle" style="font-weight:400">${personal ? "Student schedule" : "Timetable"}</span></div>${
    personal
      ? ""
      : `<div class="segmented">${[
          ["room", "教室課表"],
          ["teacher", "老師課表"],
          ["class", "班級課表"],
        ]
          .map(
            ([id, l]) =>
              `<button class="${view === id ? "selected" : ""}" data-view="${id}">${l}</button>`,
          )
          .join("")}</div>`
  }</div><div class="filters"><div class="filter-left">${personal ? `<select id="student-select" aria-label="選擇學生"><option value="">選擇個人選課清單</option>${S.enrollments.map((e) => `<option value="${e.id}" ${studentId === e.id ? "selected" : ""}>${esc(e.name)}</option>`).join("")}</select>` : `<select id="selection" aria-label="選擇課表對象">${options.map((o) => `<option ${selection === o ? "selected" : ""} value="${esc(o)}">${view === "room" ? "教室 " : view === "class" ? "班級 " : ""}${esc(o)}</option>`).join("")}</select>`}<div class="search">${icon("search")}<input id="search" placeholder="搜尋課程、老師" aria-label="搜尋課程、老師" value="${esc(query)}"></div></div><div class="week-controls"><button data-action="prev" aria-label="上一週" ${week <= S.start ? "disabled" : ""}>${icon("left")}</button><span class="week-label">${fmtDate(week)} — ${fmtDate(dateAt(week, 4))}</span><button data-action="next" aria-label="下一週" ${dateAt(week, 7) > S.end ? "disabled" : ""}>${icon("right")}</button><button data-action="thisweek">本週</button></div></div><div class="legend-line"><div class="legend"><span><i style="background:#a9bfa0"></i>原定課程</span><span><i style="background:#d6ac6e"></i>代課</span><span><i style="background:#8ca6c0"></i>調課 / 互換</span></div><span class="subtle">第 ${Math.floor((new Date(week) - new Date(S.start)) / 604800000) + 1} 週 · ${week.slice(0, 4)}</span></div>`;
}
function lessonCard(l) {
  return `<button class="lesson ${l.changeType || ""}" data-lesson="${l.id}">${l.changeType ? `<span class="mini-badge ${l.changeType === "substitute" ? "" : "blue"}">${typeNames[l.changeType]}${l.changeType === "substitute" ? "授課" : ""}</span>` : ""}<span class="course">${esc(l.name)}</span><span class="teacher">${esc(l.teachers.join("、") || "待核對")}</span><span class="place">${icon("pin")}${esc(l.room)}<span style="margin-left:auto">${l.kind === "待核定" ? "" : esc(l.kind)}</span></span></button>`;
}
function timetable(personal) {
  const ls = filteredLessons(personal),
    ghosts = S.lessons
      .filter(
        (l) =>
          l.original &&
          ["move", "swap"].includes(l.changeType) &&
          (l.day !== l.original.day ||
            l.period !== l.original.period ||
            l.room !== l.original.room),
      )
      .filter((l) => {
        const o = l.original;
        return (
          (personal
            ? student()?.lessonIds.includes(l.id)
            : view === "room"
              ? o.room === selection
              : view === "teacher"
                ? o.teachers.includes(selection)
                : o.classes.includes(selection)) &&
          `${l.name}${o.teachers.join("")}${o.room}`.includes(query)
        );
      }),
    today = new Date().toLocaleDateString("sv-SE", { timeZone: "Asia/Taipei" });
  return `<div class="grid-wrap"><table class="timetable"><thead><tr><th>節次</th>${dayNames.map((d, i) => `<th class="${dateAt(week, i) === today ? "today" : ""}">週${d}<span class="date">${fmtDate(dateAt(week, i))}</span></th>`).join("")}</tr></thead><tbody>${times
    .map(
      (t, p) =>
        `${p === 4 ? '<tr class="lunch"><td colspan="6">12:00 — 13:20　午間休息</td></tr>' : ""}<tr><td class="time">${String(p + 1).padStart(2, "0")}<small>${t}<br>${ends[p]}</small></td>${dayNames
          .map(
            (_, d) =>
              `<td>${
                ls
                  .filter((l) => l.day === d && l.period === p + 1)
                  .map(lessonCard)
                  .join("") +
                  ghosts
                    .filter(
                      (l) =>
                        l.original.day === d && l.original.period === p + 1,
                    )
                    .map(
                      (l) =>
                        `<button class="lesson origin-slot" data-lesson="${l.id}"><span class="mini-badge blue">原時段已調整</span><span class="course">${esc(l.name)}</span><span class="place">→ 週${dayNames[l.day]} ${l.period}節 · ${esc(l.room)}</span></button>`,
                    )
                    .join("") || '<span class="free">—</span>'
              }</td>`,
          )
          .join("")}</tr>`,
    )
    .join(
      "",
    )}</tbody></table></div><div class="table-footer"><span>${icon("info")} 點選課程查看詳情與當週異動</span><span>顯示 ${ls.length} 堂課</span></div>`;
}
function weeklyAside() {
  const rs = S.requests.filter(
    (r) => r.week === week && r.status === "approved",
  );
  return `<section class="panel"><div class="aside-title">本週異動動態 <span class="status">${rs.length} 筆</span></div><div class="aside-body">${
    rs.length
      ? rs
          .slice(0, 5)
          .map(
            (r) =>
              `<div class="inline-event"><span class="mini-badge ${r.type === "substitute" ? "" : "blue"}">${typeNames[r.type]}</span><br><strong>${esc(original(r.lessonId)?.name)}</strong><small>${esc(r.reason)}</small><button class="text-action" data-request="${r.id}">查看異動 →</button></div>`,
          )
          .join("")
      : `<div class="empty"><div class="empty-icon">${icon("check")}</div><b>本週課程照常進行</b>目前沒有已核准的調代課<br>新的安排會顯示在這裡</div>`
  }<button class="text-action" data-nav="requests" style="margin-top:15px">查看所有申請　→</button></div></section>`;
}
function sourceBanner() {
  return `<div class="source-banner">${icon("info")}<span><b>課表已從你的 PDF 匯入，正在等待核對。</b><br>班級歸屬為自動比對；必選修分類、線上課程與未匹配資料請先由教務處確認，再正式使用。</span><a href="#" data-nav="data">核對課表資料　↗</a></div>`;
}
function requestsPage() {
  return `<section class="panel"><div class="panel-top"><div class="panel-title">${icon("swap")} 所有調代課申請</div><span class="subtle">示範簽核 · 核准前不影響正式課表</span></div><div class="notice">此工作區示範申請與教務簽核流程，尚無真實身分驗證。正式使用前需接入學校帳號及權限控管。核准時會再次檢查衝堂。</div>${S.requests.length ? `<div class="grid-wrap"><table class="list-table"><thead><tr><th>課程 / 申請時間</th><th>異動內容</th><th>指定週次</th><th>狀態</th><th>簽核操作</th></tr></thead><tbody>${S.requests.map((r) => `<tr><td><b>${esc(original(r.lessonId)?.name)}</b><small>${stamp(r.createdAt)}</small></td><td><span class="mini-badge ${r.type === "substitute" ? "" : "blue"}">${typeNames[r.type]}</span><small>${esc(r.reason)}</small><button class="text-action" data-request="${r.id}">異動詳情 →</button></td><td>${fmtDate(r.week)} – ${fmtDate(dateAt(r.week, 4))}</td><td><span class="status ${r.status}">${statusNames[r.status]}</span></td><td><div class="actions">${r.status === "pending" ? `<button class="primary" data-decision="approve" data-id="${r.id}">核准</button><button data-decision="reject" data-id="${r.id}">退回</button>` : ""}${["pending", "approved"].includes(r.status) ? `<button class="danger" data-decision="cancel" data-id="${r.id}">撤銷</button>` : ""}</div></td></tr>`).join("")}</tbody></table></div>` : `<div class="empty" style="padding:65px"><div class="empty-icon">${icon("swap")}</div><b>還沒有調代課申請</b>從右上角「新增調代課」開始。<br>申請通過後，週課表與個人選課清單會同步更新。</div>`}</section>`;
}
function studentPage() {
  return `<section class="panel"><div class="profile-banner"><span>${icon("users")} ${student() ? esc(student().name) + " 的專屬課表" : "建立選課清單，組合自己的每一週。"}</span><div class="actions">${student() ? '<button data-action="edit-enroll">編輯選課</button>' : ""}<button data-action="enroll">＋ 新增選課清單</button></div></div>${scheduleTop(true)}${!student() ? '<div class="notice">PDF 沒有學生實際選課資料。請先建立個人選課清單；系統不會把班級課表誤當成每位學生的課表。</div>' : ""}${timetable(true)}</section>${sourceBanner()}`;
}
function reportRows() {
  const rows = new Map(
    S.teachers.map((t) => [t, { teacher: t, given: 0, taken: 0, records: [] }]),
  );
  for (const r of S.requests.filter(
    (r) => r.status === "approved" && r.type === "substitute",
  )) {
    const l = S.lessons.find((l) => l.id === r.lessonId),
      date = dateAt(r.week, l.day);
    if (!date.startsWith(reportMonth)) continue;
    const base = JSON.parse(JSON.stringify(l.original || l));
    const old = base.teachers,
      newTs = r.changes[0].teachers;
    for (const t of newTs.filter((t) => !old.includes(t))) {
      rows.get(t).given++;
      rows.get(t).records.push(`${date} ${l.name}`);
    }
    for (const t of old.filter((t) => !newTs.includes(t))) rows.get(t).taken++;
  }
  return [...rows.values()].filter((r) => r.given || r.taken);
}
function reportsPage() {
  const rows = reportRows();
  return `<section class="panel"><div class="panel-top"><div class="panel-title">${icon("chart")} 每月代課統計</div><div class="tabs-inline"><input type="month" class="month-input" id="month" aria-label="報表月份" value="${reportMonth}" min="2026-08" max="2027-01"><button data-action="report-export">${icon("download")} 匯出 CSV</button></div></div><div class="section-intro">依已核准、未撤銷的代課紀錄統計。每節 50 分鐘，鐘點費請依學校核定費率另行計算；本報表不推算薪資。</div>${rows.length ? `<div class="grid-wrap"><table class="list-table"><thead><tr><th>老師</th><th>代課節數</th><th>授課分鐘</th><th>被代課節數</th><th>代課明細</th></tr></thead><tbody>${rows.map((r) => `<tr><td>${esc(r.teacher)}</td><td>${r.given} 節</td><td>${r.given * 50} 分鐘</td><td>${r.taken} 節</td><td>${r.records.map(esc).join("<br>") || "—"}</td></tr>`).join("")}</tbody></table></div>` : '<div class="empty" style="padding:65px"><div class="empty-icon">' + icon("chart") + "</div><b>本月尚無已核准代課紀錄</b>代課申請通過後，會自動列入對應月份。</div>"}</section>`;
}
function notificationsPage() {
  const ns = student()
    ? S.notifications.filter((n) =>
        n.lessonIds.some((id) => student().lessonIds.includes(id)),
      )
    : S.notifications;
  return `<section class="panel"><div class="panel-top"><div class="panel-title">${icon("bell")} 站內通知</div><button data-action="read">全部標為已讀</button></div><div class="notice">${student() ? "顯示「" + esc(student().name) + "」選課相關通知。" : "顯示所有課務通知。"} LINE、Email 與裝置推播尚未串接；此處不代表已寄出外部訊息。開啟中的頁面即時同步異動，連線中斷時每 20 秒重試。</div>${ns.length ? ns.map((n) => `<div class="inbox-item"><b>${!n.read ? "● " : ""}${esc(n.title)}</b><p>${esc(n.body)}</p><small>${stamp(n.at)}　·　${esc(n.channel)}</small></div>`).join("") : `<div class="empty" style="padding:65px"><div class="empty-icon">${icon("bell")}</div><b>目前沒有新通知</b>當異動核准或撤銷時，將產生站內通知。</div>`}</section>`;
}
function dataPage() {
  const ls = S.lessons.filter((l) =>
    `${l.name}${l.room}${l.teachers.join("")}`.includes(query),
  );
  const chunk = ls.slice(reviewPage * 18, (reviewPage + 1) * 18);
  return `<section class="panel"><div class="panel-top"><div class="panel-title">${icon("file")} 原始課表來源</div><span class="subtle">115.08.31 — 116.01.21</span></div>${S.sources.map((s) => `<div class="source-card"><div>${icon("file")}　${esc(s.name)}<small>原始 PDF 保留存檔 · ${s.label === "room" ? "課程時段的主要來源" : s.label === "class" ? "班級歸屬交叉比對" : "教師名單及人工核對參考"}</small></div><a href="${s.url}" target="_blank" rel="noopener">檢視原檔 ↗</a></div>`).join("")}<div class="notice">匯入 ${S.lessons.length} 個每週課程時段，涵蓋 ${S.teachers.length} 位老師與 11 間教室。班級歸屬由不同日期版本的 PDF 自動比對，可能存在差異；老師課表作為核對參考，不代表三份文件已完全一致。所有課程的必選修、實體／線上安排都需人工確認。</div><div class="panel-top"><div class="panel-title">逐堂核對 <span class="subtle">${S.lessons.filter((l) => !l.needsReview).length} / ${S.lessons.length} 已確認</span></div><div class="search">${icon("search")}<input id="review-search" aria-label="搜尋待核對課程" value="${esc(query)}" placeholder="搜尋課程、老師"></div></div><div class="review-grid">${chunk.map((l) => `<article class="review-card"><h3>${esc(l.name)}</h3><span class="status ${l.needsReview ? "pending" : "approved"}">${l.needsReview ? "待核對" : "已核對"} · ${esc(l.kind)}</span><p>週${dayNames[l.day]} 第 ${l.period} 節 · ${esc(l.room)}<br>${esc(l.teachers.join("、"))}<br>比對班級：${l.classes.join("、") || "未匹配"}</p><button data-review="${l.id}">核對與分類</button></article>`).join("")}</div><div class="table-footer"><button data-action="review-prev" ${reviewPage === 0 ? "disabled" : ""}>上一頁</button><span>第 ${reviewPage + 1} / ${Math.max(1, Math.ceil(ls.length / 18))} 頁</span><button data-action="review-next" ${(reviewPage + 1) * 18 >= ls.length ? "disabled" : ""}>下一頁</button></div></section><section class="panel" style="margin-top:20px"><div class="aside-title">異動稽核紀錄 <span class="subtle">不可於介面刪除</span></div><div class="aside-body">${
    S.audit.length
      ? S.audit
          .slice(0, 15)
          .map(
            (a) =>
              `<div class="activity">${esc(a.event)}<small>${stamp(a.at)} · ${esc(a.detail)}</small></div>`,
          )
          .join("")
      : '<div class="subtle">尚無操作紀錄</div>'
  }</div></section>`;
}
function openDialog(title, body, foot = "") {
  lastFocus = document.activeElement;
  const d = $("#modal");
  d.innerHTML = `<div class="dialog-head"><h2>${title}</h2><button class="ghost" data-close aria-label="關閉對話框">${icon("close")}</button></div>${body}${foot ? `<div class="dialog-foot">${foot}</div>` : ""}`;
  d.querySelector("[data-close]").onclick = () => d.close();
  d.setAttribute("aria-label", title);
  d.showModal();
}
$("#modal").addEventListener(
  "close",
  () => lastFocus?.isConnected && lastFocus.focus(),
);
function closeDialog() {
  $("#modal").close();
}
function lessonDetails(id) {
  const l = original(id);
  openDialog(
    esc(l.name),
    `<div class="dialog-body"><div class="legend"><span class="status ${l.changeType ? "approved" : ""}">${l.changeType ? typeNames[l.changeType] + "已生效" : "原定課程"}</span><span>${esc(l.kind)} · ${l.needsReview ? "資料待核對" : "已核對"}</span></div><div class="detail-grid"><div><small>上課時間</small>${dateAt(week, l.day)}（${dayNames[l.day]}）<br>第 ${l.period} 節　${times[l.period - 1]}</div><div><small>上課教室</small>${esc(l.room)}</div><div><small>授課老師</small>${esc(l.teachers.join("、"))}${l.original ? `<br><small>原授課：${esc(l.original.teachers.join("、"))}</small>` : ""}</div><div><small>對應班級</small>${esc(l.classes.join("、") || "待人工核對")}</div></div>${l.changeType ? `<div class="form-note">本週異動：${esc(S.requests.find((r) => r.id === l.requestId)?.reason)}<br>原定：週${dayNames[l.original.day]} 第 ${l.original.period} 節 · ${esc(l.original.room)}</div>` : ""}<p class="subtle">來源：教室空間課表，第 ${l.sourcePage} 頁。<a href="/sources/room.pdf#page=${l.sourcePage}" target="_blank" rel="noopener">檢視原始 PDF ↗</a></p></div>`,
    `<button id="detail-request" class="primary">${icon("swap")} 申請本週調代課</button>`,
  );
  $("#detail-request").onclick = () => {
    closeDialog();
    requestForm(id);
  };
}
function requestDetails(id) {
  const r = S.requests.find((r) => r.id === id);
  openDialog(
    "調代課異動詳情",
    `<div class="dialog-body"><span class="status ${r.status}">${statusNames[r.status]}</span><p class="subtle">指定週次 ${r.week} · ${typeNames[r.type]}</p>${r.changes
      .map((c) => {
        const l = original(c.id),
          base = l.original || l;
        return `<div class="form-note" style="margin-top:10px"><b>${esc(l.name)}</b><br>原定：週${dayNames[base.day]} 第 ${base.period} 節 · ${esc(base.room)} · ${esc(base.teachers.join("、"))}<br>調整：週${dayNames[c.day ?? base.day]} 第 ${c.period ?? base.period} 節 · ${esc(c.room ?? base.room)} · ${esc((c.teachers || base.teachers).join("、"))}</div>`;
      })
      .join(
        "",
      )}<p style="font-size:12px;line-height:1.9">申請原因：${esc(r.reason)}</p><p class="subtle">送出時間：${stamp(r.createdAt)}</p></div>`,
  );
}
function requestForm(id) {
  const opts = S.lessons
    .map(
      (l) =>
        `<option value="${l.id}" ${l.id === id ? "selected" : ""}>週${dayNames[l.day]} ${l.period}節｜${esc(l.name)} · ${esc(l.room)} · ${esc(l.teachers.join("、"))}</option>`,
    )
    .join("");
  openDialog(
    "新增調代課申請",
    `<form id="request-form"><div class="dialog-body"><div class="form-note" style="margin-bottom:18px">異動只影響指定週次。送出時與核准時都會檢查老師、教室與已登錄學生選課是否衝堂。</div><div class="form-grid"><div class="form-group"><label for="req-week">指定週次（週一）</label><input type="date" id="req-week" name="week" value="${week}" min="${S.start}" max="${S.end}" required></div><div class="form-group"><label for="req-type">異動類型</label><select id="req-type" name="type"><option value="substitute">老師代課</option><option value="move">調整時間 / 教室</option><option value="swap">兩堂課互換時間</option></select></div></div><div class="form-group"><label for="req-lesson">原課程時段</label><select id="req-lesson" name="lessonId">${opts}</select></div><div id="request-fields"></div><div class="form-group"><label for="req-reason">申請原因</label><textarea id="req-reason" name="reason" minlength="2" maxlength="500" required placeholder="例如：教師公假，申請本週由其他老師代課"></textarea></div><div id="form-error" class="error" role="alert"></div></div><div class="dialog-foot"><button type="button" id="cancel-request">取消</button><button class="primary" type="submit">送出申請 ${icon("arrow")}</button></div></form>`,
  );
  $("#cancel-request").onclick = closeDialog;
  $("#req-type").onchange = requestFields;
  $("#req-lesson").onchange = requestFields;
  $("#req-week").onchange = async () => {
    try {
      const v = $("#req-week").value;
      const x = await api("state?week=" + v);
      S = x;
      requestFields();
      $("#form-error").textContent = "";
    } catch (e) {
      $("#form-error").textContent = e.message;
    }
  };
  requestFields();
  $("#request-form").onsubmit = async (e) => {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(e.target));
    if (data.day !== undefined) data.day = Number(data.day);
    if (data.period !== undefined) data.period = Number(data.period);
    const submit = e.target.querySelector("[type=submit]");
    submit.disabled = true;
    try {
      await api("requests", data);
      week = data.week;
      closeDialog();
      await refresh();
      toast("申請已送出，等待教務簽核。");
    } catch (e) {
      $("#form-error").textContent = e.message;
      submit.disabled = false;
    }
  };
}
function requestFields() {
  const type = $("#req-type").value,
    l = original($("#req-lesson").value);
  const teachers = S.teachers.map((t) => `<option>${esc(t)}</option>`).join(""),
    rooms = [...new Set(S.lessons.map((l) => l.room))];
  $("#request-fields").innerHTML =
    type === "substitute"
      ? `<div class="form-grid"><div class="form-group"><label for="replaced">被代課老師</label><select id="replaced" name="replacedTeacher">${l.teachers.map((t) => `<option>${esc(t)}</option>`).join("")}</select></div><div class="form-group"><label for="sub-teacher">代課老師</label><select id="sub-teacher" name="teacher">${teachers}</select></div></div>`
      : type === "move"
        ? `<div class="form-grid"><div class="form-group"><label for="move-day">調整至星期</label><select id="move-day" name="day">${dayNames.map((d, i) => `<option value="${i}" ${l.day === i ? "selected" : ""}>星期${d}</option>`).join("")}</select></div><div class="form-group"><label for="move-period">調整至節次</label><select id="move-period" name="period">${times.map((t, i) => `<option value="${i + 1}" ${l.period === i + 1 ? "selected" : ""}>第 ${i + 1} 節 ${t}</option>`).join("")}</select></div></div><div class="form-group"><label for="move-room">調整至教室</label><select id="move-room" name="room">${rooms.map((r) => `<option ${r === l.room ? "selected" : ""}>${esc(r)}</option>`).join("")}</select></div>`
        : `<div class="form-group"><label for="swap-other">互換課程（保留各自教室，交換時間）</label><select id="swap-other" name="otherId">${S.lessons
            .filter((x) => x.id !== l.id)
            .map(
              (x) =>
                `<option value="${x.id}">週${dayNames[x.day]} ${x.period}節｜${esc(x.name)} · ${esc(x.room)} · ${esc(x.teachers.join("、"))}</option>`,
            )
            .join("")}</select></div>`;
}
function enrollForm(edit = false) {
  const e = edit ? student() : null;
  const groups = new Map();
  S.lessons.forEach((l) => {
    const key = `${l.name}|${(l.original?.teachers || l.teachers).join("、")}|${l.original?.room || l.room}`;
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(l);
  });
  const entries = [...groups.entries()];
  openDialog(
    e ? "編輯個人選課" : "建立個人選課清單",
    `<form id="enroll-form"><div class="dialog-body"><div class="form-group"><label for="enroll-name">顯示名稱（示範用，請勿輸入敏感個資）</label><input id="enroll-name" name="name" value="${esc(e?.name || "")}" maxlength="40" required placeholder="例如：101 同學 A"></div><p class="form-note">以課程選課，同一課程的每週時段一起加入。系統會檢查學期原課表及已生效異動；尚未登錄的學生無法納入衝堂檢查。</p><div class="check-list">${entries.map(([k, ls], i) => `<label class="check-row"><input type="checkbox" name="group" value="${i}" ${e && ls.every((l) => e.lessonIds.includes(l.id)) ? "checked" : ""}><span>${esc(ls[0].name)}<small>${esc((ls[0].original?.teachers || ls[0].teachers).join("、"))} · ${esc(ls[0].room)} · 每週 ${ls.length} 節<br>${ls.map((l) => `週${dayNames[(l.original || l).day]} ${(l.original || l).period}節`).join("、")}</small></span></label>`).join("")}</div><div id="form-error" class="error" role="alert"></div></div><div class="dialog-foot"><button class="primary" type="submit">儲存選課清單</button></div></form>`,
  );
  $("#enroll-form").onsubmit = async (ev) => {
    ev.preventDefault();
    const fd = new FormData(ev.target);
    const ids = fd
      .getAll("group")
      .flatMap((i) => entries[Number(i)][1].map((l) => l.id));
    try {
      const out = await api("enrollments", {
        name: fd.get("name"),
        lessonIds: ids,
        ...(e ? { id: e.id } : {}),
      });
      studentId = out.id;
      localStorage.setItem("courseflow-student", studentId);
      closeDialog();
      await refresh();
      toast("個人課表已儲存。");
    } catch (e) {
      $("#form-error").textContent = e.message;
    }
  };
}
function reviewForm(id) {
  const l = original(id);
  openDialog(
    "核對匯入課程",
    `<form id="review-form"><div class="dialog-body"><h3 style="margin-top:0;font-weight:550">${esc(l.name)}</h3><p class="subtle">週${dayNames[l.day]} 第 ${l.period} 節 · ${esc(l.room)} · ${esc(l.teachers.join("、"))}</p><div class="form-note">原始文字：${esc(l.raw)}<br>請對照 <a href="/sources/room.pdf#page=${l.sourcePage}" target="_blank" rel="noopener">教室課表第 ${l.sourcePage} 頁 ↗</a>，確認課程名稱、老師與時段。若這些核心欄位有誤，請先修正資料匯入，勿將此筆標記為已核對。</div><div class="form-group" style="margin-top:18px"><label for="review-kind">課程分類</label><select id="review-kind" name="kind">${["待核定", "必修", "選修", "校定必修"].map((k) => `<option ${l.kind === k ? "selected" : ""}>${k}</option>`).join("")}</select></div><div class="form-group"><label for="review-classes">班級歸屬（逗號分隔；空白表示尚無班級）</label><input id="review-classes" name="classes" value="${l.classes.join(",")}" placeholder="101,102,103"></div><div class="form-note">「已核對」僅代表本筆文字與班級分類確認。PDF 中以底色表達的線上課程規則尚未數位化，正式上線前仍需補齊。</div><div id="form-error" class="error" role="alert"></div></div><div class="dialog-foot"><button class="primary">儲存核對結果</button></div></form>`,
  );
  $("#review-form").onsubmit = async (e) => {
    e.preventDefault();
    const f = new FormData(e.target);
    try {
      await api("review", {
        id,
        kind: f.get("kind"),
        classes: f
          .get("classes")
          .split(/[,，、]/)
          .map((s) => s.trim())
          .filter(Boolean),
      });
      closeDialog();
      await refresh();
      toast("核對結果已儲存。");
    } catch (e) {
      $("#form-error").textContent = e.message;
    }
  };
}
function csvDownload(name, rows) {
  const csv =
    "\uFEFF" +
    rows
      .map((row) =>
        row
          .map((v) => {
            let s = String(v ?? "");
            if (/^[=+@\-\t\r]/.test(s)) s = "'" + s;
            return '"' + s.replaceAll('"', '""') + '"';
          })
          .join(","),
      )
      .join("\r\n");
  const url = URL.createObjectURL(
    new Blob([csv], { type: "text/csv;charset=utf-8;" }),
  );
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}
function bind() {
  document.querySelectorAll("[data-nav]").forEach(
    (b) =>
      (b.onclick = (e) => {
        e.preventDefault();
        page = b.dataset.nav;
        query = "";
        reviewPage = 0;
        render();
        window.scrollTo(0, 0);
      }),
  );
  document.querySelectorAll("[data-view]").forEach(
    (b) =>
      (b.onclick = () => {
        view = b.dataset.view;
        query = "";
        render();
      }),
  );
  document
    .querySelectorAll("[data-lesson]")
    .forEach((b) => (b.onclick = () => lessonDetails(b.dataset.lesson)));
  document
    .querySelectorAll("[data-request]")
    .forEach((b) => (b.onclick = () => requestDetails(b.dataset.request)));
  document
    .querySelectorAll("[data-review]")
    .forEach((b) => (b.onclick = () => reviewForm(b.dataset.review)));
  document.querySelectorAll("[data-decision]").forEach(
    (b) =>
      (b.onclick = () => {
        const action = b.dataset.decision,
          id = b.dataset.id;
        openDialog(
          { approve: "核准申請", reject: "退回申請", cancel: "撤銷申請" }[
            action
          ],
          `<div class="dialog-body"><p style="font-size:13px;line-height:1.9">${action === "approve" ? "核准後，指定週次的課表將同步更新並產生站內通知。系統會再次檢查衝堂。" : action === "cancel" ? "撤銷後，這筆異動將不再套用，課表恢復原定安排並保留稽核紀錄。" : "退回後不會變更課表。紀錄將保留，可另外提出新的申請。"}</p><div class="error" id="form-error" role="alert"></div></div>`,
          `<button class="primary" id="confirm-decision">確認${action === "approve" ? "核准" : action === "reject" ? "退回" : "撤銷"}</button>`,
        );
        $("#confirm-decision").onclick = async (e) => {
          e.target.disabled = true;
          try {
            await api("decision", { id, action });
            closeDialog();
            await refresh();
            toast("申請狀態已更新。");
          } catch (err) {
            $("#form-error").textContent = err.message;
            e.target.disabled = false;
          }
        };
      }),
  );
  if ($("#selection"))
    $("#selection").onchange = (e) => {
      selection = e.target.value;
      render();
    };
  if ($("#student-select"))
    $("#student-select").onchange = (e) => {
      studentId = e.target.value;
      localStorage.setItem("courseflow-student", studentId);
      render();
    };
  for (const id of ["search", "review-search"])
    if ($("#" + id))
      $("#" + id).oninput = (e) => {
        const pos = e.target.selectionStart;
        query = e.target.value;
        reviewPage = 0;
        render();
        const el = $("#" + id);
        el.focus();
        el.setSelectionRange(pos, pos);
      };
  if ($("#month"))
    $("#month").onchange = (e) => {
      reportMonth = e.target.value;
      render();
    };
  document.querySelectorAll("[data-action]").forEach(
    (b) =>
      (b.onclick = async () => {
        try {
          switch (b.dataset.action) {
            case "new":
              requestForm();
              break;
            case "prev":
            case "next":
              week = dateAt(week, b.dataset.action === "prev" ? -7 : 7);
              await refresh();
              break;
            case "thisweek":
              week = initialWeek();
              await refresh();
              break;
            case "enroll":
              enrollForm();
              break;
            case "edit-enroll":
              enrollForm(true);
              break;
            case "read":
              await api("read", {});
              await refresh();
              toast("已全部標為已讀。");
              break;
            case "export":
              csvDownload(`週課表_${week}.csv`, [
                ["日期", "節次", "課程", "授課老師", "教室", "異動"],
                ...filteredLessons(page === "student").map((l) => [
                  dateAt(week, l.day),
                  l.period,
                  l.name,
                  l.teachers.join("、"),
                  l.room,
                  typeNames[l.changeType] || "原定",
                ]),
              ]);
              break;
            case "report-export":
              csvDownload(`代課報表_${reportMonth}.csv`, [
                ["老師", "代課節數", "授課分鐘", "被代課節數", "代課明細"],
                ...reportRows().map((r) => [
                  r.teacher,
                  r.given,
                  r.given * 50,
                  r.taken,
                  r.records.join("；"),
                ]),
              ]);
              break;
            case "review-prev":
              reviewPage--;
              render();
              break;
            case "review-next":
              reviewPage++;
              render();
              break;
          }
        } catch (e) {
          toast(e.message);
        }
      }),
  );
}
refresh().catch((e) => {
  $("#app").innerHTML =
    `<div style="padding:50px"><h1>課表暫時無法載入</h1><p>${esc(e.message)}</p><button onclick="location.reload()">重新載入</button></div>`;
});
async function syncState() {
  if (
    $("#modal").open ||
    document.activeElement?.matches("input,select,textarea")
  )
    return;
  try {
    const n = await api("state?week=" + week);
    if (JSON.stringify(n) !== JSON.stringify(S)) {
      S = n;
      render();
    }
  } catch {}
}
setInterval(syncState, 20000);
const events = new EventSource("/api/events");
events.onmessage = () => syncState();
